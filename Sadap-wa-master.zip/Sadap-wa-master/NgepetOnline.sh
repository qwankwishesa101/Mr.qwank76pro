 clear
 bi='\033[34;1m' #biru
 i='\033[32;1m' #ijo
 pur='\033[35;1m' #purple
 cy='\033[36;1m' #cyan
 me='\033[31;1m' #merah
 pu='\033[37;1m' #putih
 ku='\033[33;1m' #kuning
 mer='\033[41;97m' #Tepi
 st='\033[0m' #Stop
 
 
echo $pur"      (\____/)    " 
echo $pur"      / @__@ \ "
echo $pur"     (  (oo)  )  ╔╗╔╔═╗╔═╗╔═╗╔═╗╔╦╗  " 
echo $pur"      \-.~~.-/   ║║║║ ╦║╣ ╠═╝║╣  ║    " 
echo $pur"       /    \    ╝╚╝╚═╝╚═╝╩  ╚═╝ ╩   "       
echo $pur"     @/      \_"
echo $pur"    (/ /    \ \)"
echo $pur"     WW\----/WW"
echo ""
echo -n $cy"Masukkan Nama Daerah Ngepet Kalian : "
read Daerah
echo -n $cy"Masukkan Jumlah Target Uang : "
read uang
echo
echo -n $cy"Masukkan No Rek Lu : "
read norek
echo -n $cy"Masukkan Nama Rekening : "
read nama
echo
clear
echo "load.." | lolcat
echo "..." | lolcat
echo "...." | lolcat
echo "......." | lolcat
echo "..........." | lolcat
echo "................. SUKSES/100%" | lolcat
echo "wait.............." | lolcat 
clear
sleep 3
echo "|=====================================|" | lolcat
echo "| TRANSAKSI Hasil Ngepet Online SUKSES!|" | lolcat
echo "|=====================================|" | lolcat
echo 
echo "$nama, Uang sejumlah $uang"
echo "Telah sukses di Transfer ke Nomer Rek Lu, Silakan Di Cek Kembali Ya Takut BlomNya Masuk" | lolcat

echo " Dapet Duit Kan Tapi DuitNya Haram Loh:v!!" | lolcat
