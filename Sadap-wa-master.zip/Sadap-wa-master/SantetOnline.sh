bi='\033[34;1m' #biru
 i='\033[32;1m' #ijo
 pur='\033[35;1m' #purple
 cy='\033[36;1m' #cyan
 l='\033[31;1m' #merah
 pu='\033[37;1m' #putih
 ku='\033[33;1m' #kuning
 mer='\033[41;97m' #Tepi
 st='\033[0m' #Stop
 
 clear
 echo $l"   ,    ,    /\   /\ "
 echo $l"  /( /\ )\  _\ \_/ /_"
 echo $l"  |\_||_/| < \_   _/ >"
 echo $l"  \______/  \|0   0|/"
 echo $l"    _\/_   _(_  ^  _)_"
 echo $l"   ( () ) /°\|V^^^V|/°\ "
 echo $l"     {}   \  \_____/  /"
 echo $l"     ()   /\   )=(   /\ "
 echo $l"     {}  /  \_/\=/\_/  \ "
echo ""
echo ""
echo -n $cy"Masukan Nama Target Yang Mau Di SANTET😈: "
read t
echo $pur"<•===========================•>" 
echo -n $cy"Mau Nyantet Di Bagian Mana?: "
read b
echo $pur"<•===========================•>" 
echo -n $cy"mau senjata apa? golok? gergaji? pisau?: "
read s
echo $pur"<•===========================•>"
echo -n $pur" Enter untuk memulai santet "
read e
clear
echo $l"Target Dengan Nama $t Sedang Di santet"
sleep 10
echo $l"Bentar tod Si $t lagi di tusuk Pake $s di atas $b nya"
echo""
sleep 10
echo $l"Ohh Nampaknya Si $t Kesakitan Pada Bagian $b"
echo ""
sleep 7
echo $l"Njir Dia Kejang Kejang Bro:v"
sleep 9
echo $l"Anjir Klenger Dia Awokwokwok"
sleep 8
echo $l"Udhan Bep, Ga Tega Goblok :v "
sleep 4
echo ""
echo $i" Sukses!! Btw Lu Ngelayat Dulu Sana Ke Rumah Si $t, Kasian Dia Bep, Siapa Tau Lu Dapet Makanan AwokAwok:v"
 echo""
 echo""
echo $cy "Dosa Lu Tanggung Sendiri Kamprett!1!1!"
echo ""
exit
