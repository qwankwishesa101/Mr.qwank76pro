bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
mer='\033[41;97m' #Tepi
st='\033[0m' #Stop
###############################
clear
echo $pur"             \  /"
echo $pur"              \/"
echo $pur"    .===============."
echo $pur"    | .-----------. |"
echo $pur"    | |           | |"
echo $pur"    | |  Ini TV!  | |"
echo $pur"    | |           | |   __"
echo $pur"    | '-----------'o|  |o.|"
echo $pur"    |===============|  |::|"
echo $pur"    |###############|  |::|"
echo $pur"    '==============='  '--'"
echo ""
echo -n $cy" Masukin Nomer Token Listrik Lu Om!: "
read t
echo $pur"<•===========================•>"
echo -n $cy" Jadi Beneran Mau Hack Listrik Nih?: "
read kl
echo $pur"<•===========================•>"
echo $me "Tunggu Bentar Ya Mamank "
sleep 7
echo $mer"Sedang Memutuskan Aliran listrik pada $t $st"
echo $ku"Perhatiin Baik² PanduanNya Bambank " 
sleep 5
clear
echo $cy"1. Jangan Sampe Mati Hp Lu Ok"
sleep 4
echo ""
echo $pur"<•===========================•>"
echo ""
echo $cy"2. Dekatkan Hp Dengan Kontak Listrik"
sleep 4
echo ""
echo $pur"<•===========================•>"
echo ""
echo $cy"3. Tempelkan Hp Lu Dengan Kontak Listrik Ujung Bawah"
sleep 4
echo ""
echo $pur"<•===========================•>"
echo ""
echo $cy"4. Tekan Saklar ( Kontak Listrik ) Menggunakan Hp, Pada Bagian Ujung Bawah Saklar"
sleep 4
echo ""
echo $mer "Done Kan Mamank!? $st"
echo $ku " Awowkwowkkwokwwkwkw"
exit
